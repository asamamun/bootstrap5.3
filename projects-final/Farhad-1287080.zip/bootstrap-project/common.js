// Initialize cart and wishlist
let cart = JSON.parse(localStorage.getItem("cart")) || [];
let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];

// Update cart and wishlist counters
function updateCounters() {
    const cartCounters = document.querySelectorAll(".cart-counter .cart-badge");
    const wishlistCounters = document.querySelectorAll(".wishlist-counter .cart-badge");

    cartCounters.forEach(counter => counter.textContent = cart.length);
    wishlistCounters.forEach(counter => counter.textContent = wishlist.length);
}

// Add to Cart Functionality
document.querySelectorAll(".add-to-cart").forEach(button => {
    button.addEventListener("click", () => {
        const product = {
            id: button.dataset.id,
            name: button.dataset.name,
            price: parseFloat(button.dataset.price),
            image: button.dataset.image,
            quantity: 1
        };

        // Check if product already exists in cart
        const existingItem = cart.find(item => item.id === product.id);
        if (existingItem) {
            existingItem.quantity += 1; // Increase quantity if already in cart
        } else {
            cart.push(product); // Add new item to cart
        }

        // Save to localStorage
        localStorage.setItem("cart", JSON.stringify(cart));

        // Update counters
        updateCounters();

        // Redirect to cart.html
        window.location.href = "cart.html";
    });
});

// Add to Wishlist Functionality
document.querySelectorAll(".wishlist-btn").forEach(button => {
    button.addEventListener("click", () => {
        const product = {
            id: button.dataset.id,
            name: button.dataset.name,
            price: parseFloat(button.dataset.price),
            image: button.dataset.image
        };

        // Check if product already exists in wishlist
        const existingItem = wishlist.find(item => item.id === product.id);
        if (existingItem) {
            alert(`${product.name} is already in your wishlist!`);
        } else {
            wishlist.push(product); // Add new item to wishlist
            localStorage.setItem("wishlist", JSON.stringify(wishlist));
            updateCounters();
            alert(`${product.name} added to wishlist!`);
        }

        // Toggle wishlist button state
        button.classList.toggle("active");
        button.querySelector("i").classList.toggle("fas"); // Solid heart
        button.querySelector("i").classList.toggle("far"); // Regular heart
    });
});

// Initialize counters on page load
updateCounters();