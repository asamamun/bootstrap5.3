// Fetch cart data from localStorage
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Function to render cart items
function renderCartItems() {
    const cartContainer = document.getElementById("cart-items-container");
    const itemCount = document.getElementById("cart-item-count");
    const subtotal = document.getElementById("cart-subtotal");
    const total = document.getElementById("cart-total");

    if (cart.length === 0) {
        cartContainer.innerHTML = `
            <div class="text-center py-5">
                <p class="text-muted">Your cart is empty.</p>
                <a href="index.html" class="btn btn-warning">Continue Shopping</a>
            </div>
        `;
        itemCount.textContent = 0;
        subtotal.textContent = "0 TK";
        total.textContent = "100 TK";
        return;
    }

    let cartHTML = "";
    let cartSubtotal = 0;

    cart.forEach(item => {
        cartSubtotal += item.price * item.quantity;
        cartHTML += `
            <div class="cart-item border-bottom border-secondary pb-4 mb-4">
                <div class="row g-4">
                    <div class="col-md-3">
                        <img src="${item.image}" class="img-fluid rounded" alt="${item.name}">
                    </div>
                    <div class="col-md-9">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h5 class="text-warning">${item.name}</h5>
                                <p class="mb-2">Price: ${item.price} TK</p>
                            </div>
                            <button class="btn btn-link text-danger p-0 remove-item" data-id="${item.id}">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="d-flex align-items-center gap-3 mt-3">
                            <div class="quantity-control">
                                <button class="btn btn-sm btn-outline-warning decrement" data-id="${item.id}">-</button>
                                <input type="number" class="form-control bg-dark text-light text-center" 
                                       value="${item.quantity}" min="1" style="width: 60px;">
                                <button class="btn btn-sm btn-outline-warning increment" data-id="${item.id}">+</button>
                            </div>
                            <h5 class="mb-0">Total: ${item.price * item.quantity} TK</h5>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });

    cartContainer.innerHTML = cartHTML;
    itemCount.textContent = cart.length;
    subtotal.textContent = `${cartSubtotal} TK`;
    total.textContent = `${cartSubtotal + 100} TK`;

    // Add event listeners for dynamic buttons
    document.querySelectorAll(".remove-item").forEach(btn => {
        btn.addEventListener("click", () => removeFromCart(btn.dataset.id));
    });

    document.querySelectorAll(".quantity-control button").forEach(btn => {
        btn.addEventListener("click", () => updateQuantity(btn.dataset.id, btn.classList.contains("increment") ? 1 : -1));
    });
}

// Function to remove item from cart
function removeFromCart(id) {
    cart = cart.filter(item => item.id !== parseInt(id));
    localStorage.setItem("cart", JSON.stringify(cart));
    renderCartItems();
}

// Function to update item quantity
function updateQuantity(id, change) {
    const item = cart.find(item => item.id === parseInt(id));
    if (item) {
        item.quantity += change;
        if (item.quantity < 1) item.quantity = 1;
        localStorage.setItem("cart", JSON.stringify(cart));
        renderCartItems();
    }
}

// Initial render
renderCartItems();