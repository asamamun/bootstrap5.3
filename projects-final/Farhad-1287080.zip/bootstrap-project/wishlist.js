// Fetch wishlist data from localStorage
let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];

// Function to render wishlist items
function renderWishlistItems() {
    const wishlistContainer = document.getElementById("wishlist-items-container");

    if (wishlist.length === 0) {
        wishlistContainer.innerHTML = `
            <div class="text-center py-5">
                <p class="text-muted">Your wishlist is empty.</p>
                <a href="index.html" class="btn btn-warning">Continue Shopping</a>
            </div>
        `;
        return;
    }

    let wishlistHTML = "";

    wishlist.forEach(item => {
        wishlistHTML += `
            <div class="wishlist-item border-bottom border-secondary pb-4 mb-4">
                <div class="row g-4 align-items-center">
                    <div class="col-md-3">
                        <img src="${item.image}" class="img-fluid rounded" alt="${item.name}">
                    </div>
                    <div class="col-md-6">
                        <h5 class="text-warning">${item.name}</h5>
                        <p class="mb-2">Price: ${item.price} TK</p>
                        <p class="${item.inStock ? "text-success" : "text-danger"}">
                            ${item.inStock ? "In Stock" : "Out of Stock"}
                        </p>
                    </div>
                    <div class="col-md-3 text-end">
                        <button class="btn btn-warning mb-2 add-to-cart" data-id="${item.id}">Add to Cart</button>
                        <button class="btn btn-danger remove-item" data-id="${item.id}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    });

    wishlistContainer.innerHTML = wishlistHTML;

    // Add event listeners for dynamic buttons
    document.querySelectorAll(".remove-item").forEach(btn => {
        btn.addEventListener("click", () => removeFromWishlist(btn.dataset.id));
    });

    document.querySelectorAll(".add-to-cart").forEach(btn => {
        btn.addEventListener("click", () => addToCart(btn.dataset.id));
    });
}

// Function to remove item from wishlist
function removeFromWishlist(id) {
    wishlist = wishlist.filter(item => item.id !== parseInt(id));
    localStorage.setItem("wishlist", JSON.stringify(wishlist));
    renderWishlistItems();
}

// Function to add item to cart
function addToCart(id) {
    const item = wishlist.find(item => item.id === parseInt(id));
    if (item) {
        // Add to cart logic
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        const existingItem = cart.find(cartItem => cartItem.id === item.id);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ ...item, quantity: 1 });
        }
        localStorage.setItem("cart", JSON.stringify(cart));
        alert(`${item.name} added to cart!`);
    }
}

// Initial render
renderWishlistItems();